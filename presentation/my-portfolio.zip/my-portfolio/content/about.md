---
title: "About Me"
draft: false
build:
  render: never
  list: never
  publishResources: false
---

# About Me

I am a cybersecurity major at NKU.
I like to read and to play video games.

---